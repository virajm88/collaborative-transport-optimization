from itertools import combinations
import unittest

from collab_transport.game import (assess_allocation, coalitions, minimum_core_relaxation,
                                  shapley_costs, solve_coalition_costs)
from test_optimization import tiny_instance


class GameTests(unittest.TestCase):
    def test_exact_two_player_transport_game(self):
        instance = tiny_instance()
        costs, _ = solve_coalition_costs(instance)
        self.assertAlmostEqual(costs[frozenset(["A"])], 24)
        self.assertAlmostEqual(costs[frozenset(["B"])], 31)
        self.assertAlmostEqual(costs[frozenset(["A", "B"])], 45)
        allocation = shapley_costs(instance.companies, costs)
        self.assertAlmostEqual(allocation["A"], 19)
        self.assertAlmostEqual(allocation["B"], 26)
        self.assertTrue(assess_allocation(instance.companies, costs, allocation)["in_core"])

    def test_shapley_efficiency_symmetry_and_dummy(self):
        players = ("A", "B", "dummy")
        costs = {s: float(10 * len(s - {"dummy"}) - (4 if {"A", "B"} <= s else 0))
                 for s in coalitions(players, include_empty=True)}
        allocation = shapley_costs(players, costs)
        self.assertAlmostEqual(sum(allocation.values()), costs[frozenset(players)])
        self.assertAlmostEqual(allocation["A"], allocation["B"])
        self.assertAlmostEqual(allocation["dummy"], 0)

    def test_individual_rationality_does_not_imply_coalition_stability(self):
        # Every singleton costs 10, pairs AB=4, AC=BC=10, grand=12.
        # Shapley = (3,3,6): individual rationality holds, but AB pays 6>4.
        players = ("A", "B", "C")
        costs = {frozenset(): 0.0, frozenset(players): 12.0}
        for p in players:
            costs[frozenset([p])] = 10.0
        for pair in combinations(players, 2):
            costs[frozenset(pair)] = 4.0 if set(pair) == {"A", "B"} else 10.0
        allocation = shapley_costs(players, costs)
        assessment = assess_allocation(players, costs, allocation)
        self.assertTrue(assessment["individually_rational"])
        self.assertFalse(assessment["in_core"])
        self.assertEqual(assessment["blocking_coalitions"][0]["coalition"], "A|B")
        # A different allocation exists in the core: failure of Shapley is not an empty core.
        core = minimum_core_relaxation(players, costs)
        self.assertTrue(core["core_exists"])
        self.assertTrue(core["assessment"]["in_core"])

    def test_empty_core_and_positive_relaxation(self):
        players = ("A", "B", "C")
        costs = {frozenset(): 0.0}
        for s in coalitions(players):
            costs[s] = {1: 10.0, 2: 10.0, 3: 18.0}[len(s)]
        core = minimum_core_relaxation(players, costs)
        self.assertFalse(core["core_exists"])
        self.assertAlmostEqual(core["minimum_epsilon"], 2.0)
        self.assertFalse(core["assessment"]["in_core"])

    def test_single_player(self):
        players = ("A",)
        costs = {frozenset(): 0.0, frozenset(players): 7.0}
        self.assertEqual(shapley_costs(players, costs), {"A": 7.0})
        self.assertTrue(minimum_core_relaxation(players, costs)["core_exists"])

    def test_inefficient_allocation_fails_core_check(self):
        players = ("A", "B")
        costs = {frozenset(): 0.0, frozenset(["A"]): 10.0,
                 frozenset(["B"]): 10.0, frozenset(players): 15.0}
        check = assess_allocation(players, costs, {"A": 1.0, "B": 1.0})
        self.assertFalse(check["efficient"])
        self.assertFalse(check["in_core"])

    def test_incomplete_or_nonfinite_game_is_rejected(self):
        with self.assertRaises(ValueError):
            shapley_costs(("A", "B"), {frozenset(): 0})
        with self.assertRaises(ValueError):
            shapley_costs(("A",), {frozenset(): 0, frozenset(["A"]): float("nan")})


if __name__ == "__main__":
    unittest.main()

