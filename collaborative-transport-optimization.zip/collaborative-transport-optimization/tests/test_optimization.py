from dataclasses import replace
from itertools import product
import json
from pathlib import Path
import tempfile
import unittest

import numpy as np

from collab_transport.benders import solve_benders
from collab_transport.data import Hub, Instance, Order, generate_instance, load_instance
from collab_transport.model import (OptimizationError, solve_compact, solve_recourse,
                                   validate_solution)


def tiny_instance():
    # Distance origin->hub is 10; hub->orders is 0. Unit hub cost = 7;
    # direct unit cost = 22. Opening costs 10; demand is 5. Optimum 10+7*5=45.
    return Instance("hand-computable", ("A", "B"), (Hub("H", 10, 0, 10, 5),),
                    (Order("a", "A", 10, 0, 2), Order("b", "B", 10, 0, 3)))


class OptimizationTests(unittest.TestCase):
    def test_hand_computable_optimum(self):
        for function in (solve_compact, solve_benders):
            result = function(tiny_instance())
            self.assertAlmostEqual(result.objective, 45.0, places=6)
            self.assertEqual(result.y, [1.0])
            validate_solution(tiny_instance(), result)

    def test_scarce_capacity_requires_direct_delivery(self):
        instance = replace(tiny_instance(), hubs=(Hub("H", 10, 0, 10, 2),))
        for function in (solve_compact, solve_benders):
            result = function(instance)
            self.assertAlmostEqual(result.objective, 90.0, places=6)
            self.assertAlmostEqual(sum(result.direct), 3.0, places=6)

    def test_all_closed_recourse_is_feasible(self):
        sub = solve_recourse(tiny_instance(), np.zeros(1))
        self.assertAlmostEqual(sub.objective, 110.0)
        self.assertAlmostEqual(sub.flows.sum(), 0.0)

    def test_expensive_hubs_remain_closed(self):
        instance = replace(tiny_instance(), hubs=(Hub("H", 10, 0, 1e6, 5),))
        for function in (solve_compact, solve_benders):
            result = function(instance)
            self.assertAlmostEqual(result.objective, 110.0)
            self.assertEqual(result.y, [0.0])

    def test_zero_cost_degeneracy(self):
        instance = replace(tiny_instance(), linehaul_rate=0, delivery_rate=0,
                           handling_cost=0, direct_rate=0, direct_base_cost=0,
                           hubs=(Hub("H", 10, 0, 0, 5),))
        self.assertAlmostEqual(solve_compact(instance).objective, 0.0)
        self.assertAlmostEqual(solve_benders(instance).objective, 0.0)

    def test_benders_and_milp_match_exhaustive_hub_enumeration(self):
        for seed in (3, 42, 99):
            with self.subTest(seed=seed):
                instance = generate_instance(seed, 3, 3, 3)
                fixed = np.array([h.fixed_cost for h in instance.hubs])
                candidates = [fixed @ np.array(y) + solve_recourse(instance, np.array(y)).objective
                              for y in product((0., 1.), repeat=3)]
                oracle = min(candidates)
                self.assertAlmostEqual(solve_compact(instance).objective, oracle, places=5)
                self.assertAlmostEqual(solve_benders(instance).objective, oracle, places=5)

    def test_dual_cuts_are_tight_locally_and_valid_elsewhere(self):
        instance = generate_instance(7, 2, 2, 3)
        demand = np.array([o.demand for o in instance.orders])
        capacity = np.array([h.capacity for h in instance.hubs])
        query_points = [np.array(y) for y in product((0., 1.), repeat=3)]
        query_points.append(np.array([0.2, 0.7, 0.4]))
        values = [solve_recourse(instance, y).objective for y in query_points]
        for y in (np.zeros(3), np.ones(3), np.array([0.5, 0.3, 0.8])):
            sub = solve_recourse(instance, y)
            intercept, slope = demand @ sub.alpha, capacity * sub.beta
            self.assertTrue(np.all(sub.beta <= 1e-7))
            self.assertAlmostEqual(intercept + slope @ y, sub.objective, places=5)
            for other, true_value in zip(query_points, values):
                self.assertLessEqual(intercept + slope @ other, true_value + 1e-5)

    def test_benders_bounds_are_valid_and_monotone(self):
        instance = generate_instance(42, 3, 4, 4)
        optimum = solve_compact(instance).objective
        result = solve_benders(instance)
        lower = [r["lower_bound"] for r in result.history]
        upper = [r["upper_bound"] for r in result.history]
        self.assertTrue(all(v <= optimum + 1e-5 for v in lower))
        self.assertTrue(all(v >= optimum - 1e-5 for v in upper))
        self.assertTrue(all(a <= b + 1e-6 for a, b in zip(lower, lower[1:])))
        self.assertTrue(all(a >= b - 1e-6 for a, b in zip(upper, upper[1:])))
        self.assertLessEqual(result.relative_gap, 1e-7)

    def test_iteration_limit_is_not_reported_optimal(self):
        with self.assertRaises(OptimizationError):
            solve_benders(tiny_instance(), max_iterations=1)

    def test_validation_detects_tampered_flow_and_objective(self):
        instance = tiny_instance()
        result = solve_compact(instance)
        result.direct[0] += 1
        with self.assertRaisesRegex(ValueError, "Demand"):
            validate_solution(instance, result)
        result = solve_compact(instance)
        result.objective += 1
        with self.assertRaisesRegex(ValueError, "objective"):
            validate_solution(instance, result)

    def test_seed_reproducibility_and_json_roundtrip(self):
        first = generate_instance(42)
        self.assertEqual(first, generate_instance(42))
        self.assertNotEqual(first, generate_instance(43))
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "instance.json"
            first.write(path)
            self.assertEqual(first, load_instance(path))

    def test_invalid_input_is_rejected(self):
        with self.assertRaises(ValueError):
            generate_instance(n_companies=9)
        with self.assertRaises(ValueError):
            replace(tiny_instance(), orders=(Order("a", "A", 10, 0, -1),))
        with self.assertRaises(ValueError):
            replace(tiny_instance(), direct_rate=float("nan"))
        with self.assertRaises(ValueError):
            solve_recourse(tiny_instance(), np.array([2.0]))
        with self.assertRaises(ValueError):
            solve_compact(tiny_instance(), time_limit=0)


if __name__ == "__main__":
    unittest.main()

