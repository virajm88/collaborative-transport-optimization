from contextlib import redirect_stdout, redirect_stderr
import csv
import io
import json
from pathlib import Path
import tempfile
import unittest

from collab_transport.cli import main
from collab_transport.data import load_instance
from collab_transport.experiments import benchmark, run_study, sensitivity
from test_optimization import tiny_instance


class WorkflowTests(unittest.TestCase):
    def test_end_to_end_report_and_machine_readable_outputs(self):
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory)
            summary = run_study(tiny_instance(), output)
            self.assertAlmostEqual(summary["separate_cost"], 55)
            self.assertAlmostEqual(summary["collaborative_cost"], 45)
            self.assertTrue(summary["shapley_stability"]["in_core"])
            for file in ("report.md", "summary.json", "coalition_costs.csv",
                         "allocations.csv", "flows.csv", "stability_checks.csv",
                         "environment.json", "benders_history.csv", "hub_utilization.csv",
                         "figures/network.png", "figures/allocation.png",
                         "figures/benders_convergence.png"):
                self.assertTrue((output / file).is_file(), file)
            self.assertEqual(json.loads((output / "summary.json").read_text()), summary)
            with (output / "coalition_costs.csv").open() as file:
                self.assertEqual(len(list(csv.DictReader(file))), 3)

    def test_sensitivity_recomputes_and_preserves_baseline(self):
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory)
            rows = sensitivity(tiny_instance(), output)
            self.assertEqual(len(rows), 9)
            for row in rows:
                if row["factor"] == 1:
                    self.assertAlmostEqual(row["separate_cost"], 55)
                    self.assertAlmostEqual(row["collaborative_cost"], 45)
            details = json.loads((output / "scenario_details.json").read_text())
            self.assertEqual(len(details), 9)
            self.assertEqual(len(details[0]["coalition_costs"]), 4)

    def test_benchmark_compares_same_models_and_writes_evidence(self):
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory)
            rows = benchmark(output, [2], [2], [7, 42])
            self.assertEqual(len(rows), 2)
            self.assertEqual({r["solve_order"] for r in rows},
                             {"compact_then_benders", "benders_then_compact"})
            self.assertTrue(all(r["absolute_difference"] < 1e-4 for r in rows))
            self.assertEqual(len(list((output / "instances").glob("*.json"))), 2)
            self.assertTrue((output / "report.md").is_file())

    def test_cli_generate_and_solve(self):
        with tempfile.TemporaryDirectory() as directory, redirect_stdout(io.StringIO()):
            instance = Path(directory) / "input.json"
            solution = Path(directory) / "solution.json"
            main(["generate", "--companies", "1", "--hubs", "1",
                  "--orders-per-company", "2", "--output", str(instance)])
            self.assertEqual(len(load_instance(instance).orders), 2)
            main(["solve", "--instance", str(instance), "--method", "benders",
                  "--output", str(solution)])
            self.assertEqual(json.loads(solution.read_text())["status"], "optimal")

    def test_cli_invalid_company_count_exits_with_actionable_error(self):
        with redirect_stderr(io.StringIO()) as error:
            with self.assertRaises(SystemExit) as exit_info:
                main(["generate", "--companies", "9"])
            self.assertEqual(exit_info.exception.code, 2)
            self.assertIn("1 to 8 companies", error.getvalue())


if __name__ == "__main__":
    unittest.main()

