# Reference-run validation

Validated on **30 October 2026**, using Python **3.12.14**, NumPy **2.3.5**,
SciPy **1.17.0** and Matplotlib **3.10.8**. The optimisation engine is HiGHS
through SciPy. Machine details are in each experiment's `environment.json`.

## Checks completed

| Check | Outcome |
| --- | --- |
| Unit and workflow tests | 24 passed |
| Analytical tiny model, both methods | EUR 45.00 |
| MILP and Benders versus exhaustive hub search | Passed for 3 seeded small instances |
| Dual cuts: local equality and lower bounds at other points | Passed |
| Benders bound monotonicity and convergence | Passed |
| Exact Shapley properties and coalition checks | Passed |
| Empty-core and Shapley-outside-core examples | Passed |
| Full main study | Completed |
| Sensitivity scenarios | 9 completed |
| Algorithm benchmark | 9 instances, all objective differences 0.0 in this run |
| Python package wheel build | Successful |
| Installed console command outside source folder | Successful, EUR 45.00 tiny model |

The test log is included as `tests.txt`. The full main study, sensitivity and
algorithm benchmark were generated sequentially by `python reproduce.py`,
without running those experiment jobs concurrently. Reference outputs are
measurements from actual solves; runtimes vary by hardware and load.

## Reproduce

From the repository root, after installing `requirements.txt`:

```bash
python -m unittest discover -s tests -v
python reproduce.py
```

This creates fresh results under `outputs/`. Committed reference results stay
in this directory. Inspect `demo/summary.json`, `demo/coalition_costs.csv`,
`sensitivity/scenario_details.json`, `benchmark/benchmark.csv` and
`benchmark/histories/` for machine-readable evidence.

The included GitHub workflow is configured for Python 3.11 and 3.12. It has
not been run on the user's GitHub account as part of this local validation.

## What these checks establish

They support correctness on the analytical examples, seeded small instances,
listed counterexamples and measured synthetic benchmark. They do not prove
correctness for every possible input, computational superiority on large instances,
real-world commercial savings, or readiness for every research task in a PhD.

