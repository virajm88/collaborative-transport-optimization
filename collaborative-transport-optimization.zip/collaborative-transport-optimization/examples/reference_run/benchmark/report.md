# Algorithm comparison

Both methods solve the same synthetic model. Every row passed an objective-agreement check.

| Orders (total) | Hubs | Seed | Compact (s) | Benders (s) | Benders iterations | Objective difference |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 18 | 4 | 7 | 0.01035 | 0.03218 | 4 | 0 |
| 18 | 4 | 42 | 0.00659 | 0.02431 | 4 | 0 |
| 18 | 4 | 101 | 0.00752 | 0.02528 | 4 | 0 |
| 36 | 6 | 7 | 0.05852 | 0.04898 | 6 | 0 |
| 36 | 6 | 42 | 0.03737 | 0.06807 | 6 | 0 |
| 36 | 6 | 101 | 0.04437 | 0.02861 | 4 | 0 |
| 72 | 8 | 7 | 0.06610 | 0.07674 | 7 | 0 |
| 72 | 8 | 42 | 0.06679 | 0.03682 | 5 | 0 |
| 72 | 8 | 101 | 0.10895 | 0.08873 | 7 | 0 |

![Runtime](benchmark.png)

Warm-up solves are excluded; measured method order alternates. Each instance is timed once. These are small synthetic problems from one generator and one machine. Runtime differences include Python overhead and depend on solver versions, hardware and load. They do not establish large-scale superiority. Capacity scales with generated total demand. Inspect benchmark.csv, histories/ and environment.json for the underlying measurements.
