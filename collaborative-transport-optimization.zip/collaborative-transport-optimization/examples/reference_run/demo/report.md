# Collaborative transport planning: computed results

All data are synthetic. These are computational results, not observed commercial savings.

## Experiment

- Instance: `synthetic-antwerp-inspired-42`; seed: 42.
- 3 companies, 18 orders, 4 hubs.
- All costs are EUR per synthetic planning period; flows are divisible load units.
- Separate-operation cost: **EUR 5,236.98**.
- Grand-coalition cost: **EUR 4,665.82**.
- Modelled savings: **EUR 571.16 (10.91%)**.

## Exact Shapley cost allocation

| Company | Separate cost | Shapley cost | Saving |
| --- | ---: | ---: | ---: |
| Scheldt Freight | 1,966.04 | 1,769.88 | 196.16 |
| Delta Logistics | 1,303.84 | 1,132.62 | 171.21 |
| Harbour Cargo | 1,967.10 | 1,763.32 | 203.78 |

- Efficient: **True**.
- Individually rational: **True**.
- Shapley allocation in the core: **True**.
- Core exists: **True**.
- Minimum non-negative uniform coalition relaxation: **EUR 0.000000**.

Every proper coalition is checked in `stability_checks.csv`. A positive excess means
the coalition pays more than it would pay in isolation. Shapley fairness does not
guarantee stability. A core allocation, where one exists, need not be unique.

## Algorithm verification

| Method | Runtime (s) | Relative gap | Iterations |
| --- | ---: | ---: | ---: |
| Compact MILP | 0.008249 | 0 | Solver managed |
| Explicit Benders | 0.029761 | 0 | 4 |

Absolute objective difference: **0.00000000 EUR**.
Objective agreement is checked automatically; tied optimal flow plans may differ.
Hardware and dependency versions are in `environment.json`. One runtime is not
evidence of general superiority; use the multi-seed benchmark for broader comparisons.

![Network](figures/network.png)

![Allocation](figures/allocation.png)

![Benders bounds](figures/benders_convergence.png)

## Interpretation and limitations

This is a transferable-utility cooperative cost game built on a capacitated
hub-activation model. It assumes divisible demand, deterministic costs, a common
origin, enforceable transfers and unlimited direct delivery. Coalition costs are
counterfactual solves with identical hub-service offers; separate plans are not a
joint feasibility certificate for one physical network. Pooling does not receive
duplicated capacity from separately evaluated coalitions. Negative savings and
an empty core are possible; the code does not assume subadditivity.

This model is not a non-cooperative equilibrium, vehicle-routing problem, bilevel
model or implementation of column generation/branch-and-price. These experiments
do not establish a new theorem, a novel algorithm or real-world savings.
