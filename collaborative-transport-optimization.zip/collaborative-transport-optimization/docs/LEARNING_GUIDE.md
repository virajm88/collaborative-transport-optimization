# Code walkthrough and research discussion guide

This guide helps you understand and extend the implementation. It is not a claim
that you already have expertise in every method used. Run and inspect the project
before describing your contribution in an application or interview.

## 1. Start with a case you can calculate yourself

Run:

```bash
python -m collab_transport demo --instance data/tiny_instance.json --output outputs/tiny
```

There are two players, A and B, with demand 2 and 3 at the same customer coordinate.
One hub has capacity 5 and opening cost EUR 10. Via-hub cost is EUR 7 per unit;
direct transport costs EUR 22 per unit.

| Plan | Calculation | Cost |
| --- | --- | ---: |
| A alone, using hub | 10 + 2 × 7 | 24 |
| B alone, using hub | 10 + 3 × 7 | 31 |
| Both together, using hub | 10 + 5 × 7 | 45 |
| Both delivered directly | 5 × 22 | 110 |

Sharing the hub saves EUR 10 of duplicated activation cost. For two players,
Shapley takes the average of each player's contribution when joining first and last:

- A: `(24 + (45 − 31)) / 2 = 19`.
- B: `(31 + (45 − 24)) / 2 = 26`.

The allocations sum to 45; each player saves 5 versus operating alone. This
allocation is in the core because neither singleton pays more than its own cost.

Now edit hub capacity from 5 to 2 in a copy of the JSON file. Joint planning must
send 3 units directly, giving `10 + 2×7 + 3×22 = 90`. Ask why the independent
standalone comparison does not automatically have the same capacity restriction.
This exposes the modelling assumptions about outside options.

## 2. Read the code in this order

1. `data.py`: demand, costs, coordinates and validation.
2. `model.py`: the variable ordering, sparse constraints and LP subproblem.
3. `tests/test_optimization.py`: compare the solver with the hand calculation and
   an exhaustive search over small hub configurations.
4. `benders.py`: follow one master solution, its dual values, the resulting cut,
   and the lower / upper bounds.
5. `game.py`: trace the Shapley weights and the sign of coalition excess.
6. `experiments.py`: see how models become reproducible evidence.

## 3. Concepts you should be able to explain

**Why is this a MILP?** Hub activation is binary; shipment quantities are continuous.
The objective and constraints are linear. The integer decisions make it different
from an ordinary continuous transportation LP.

**Why is order splitting allowed?** Continuous flows keep the allocation subproblem
an LP, allowing classical dual Benders cuts. Indivisible shipments would change
the subproblem and invalidate this derivation without another method.

**What does the master know?** It chooses hubs and a lower approximation of shipment
cost. Every added dual cut strengthens that approximation.

**Why is the subproblem always feasible?** It can deliver every unit directly.
Without that option, some closed-hub patterns might require feasibility cuts.

**Why are capacity multipliers non-positive?** In this minimisation LP, increasing
available capacity cannot worsen the optimum. The non-positive multiplier is the
local derivative with respect to the capacity upper bound.

**How do you know the cuts are valid?** They come from feasible LP dual solutions;
weak duality gives a lower bound everywhere, and strong duality gives equality
at the generating point. Tests check both numerically on small examples.

**Why is Shapley not enough?** A rule can allocate cost fairly by marginal
contributions yet overcharge a particular coalition relative to its outside option.
The project checks all coalitions separately and tests whether another allocation
can satisfy the core inequalities.

**What does an empty core mean here?** No budget-balanced allocation can prevent
every coalition from preferring its specified outside option. It depends on the
definition of those options and does not establish a universal claim about logistics.

**Does Benders run faster?** Inspect the measured results. Small instances may
favour the compact MILP because an outer loop incurs repeated solver overhead.
There is no claim of general speedup.

**Is this a strategic equilibrium model?** No. It is a cooperative,
transferable-utility cost game whose coalition values are computed by optimisation.
Strategic pricing and non-cooperative equilibrium are potential extensions.

## 4. Make a contribution of your own

Choose one change, state its expected effect, implement it, and write up the result.

- **Resource pooling:** add member-contributed hub capacities. Compare core existence
  with the fixed-capacity outside-option convention. Decide how fixed costs should
  scale and document why; avoid changing capacity silently.
- **Repeated timing:** run each benchmark several times, vary measured solve order
  and report medians and ranges by size. Keep objective-agreement checks.
- **Counterexample search:** vary seeds and capacity; find cases with positive
  aggregate savings but a Shapley allocation outside the core. Check whether
  another allocation lies in the core before calling the core empty.
- **A stronger algorithm:** investigate disaggregated Benders cuts after deriving
  a valid subproblem separation. Benchmark against the existing single-cut method.

Record the change, tests, observations and limitations in a short new Markdown
note. That makes your own research judgement visible in the repository history.

## 5. A short preparation sequence

| Session | Task | Deliverable |
| --- | --- | --- |
| 1 | Run the tiny and default examples; reproduce costs by hand | Notes on variables and constraints |
| 2 | Derive the LP dual and inspect the first two Benders cuts | A worked cut calculation |
| 3 | Recalculate the two-player Shapley values; inspect coalition excesses | A stability explanation |
| 4 | Change one modelling assumption and rerun relevant tests | A small documented extension |
| 5 | Re-run experiments and discuss what the evidence supports | A concise project explanation |

