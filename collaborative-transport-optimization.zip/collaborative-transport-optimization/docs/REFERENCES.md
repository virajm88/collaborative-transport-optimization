# References and implementation provenance

## Mathematical methods

1. Benders, J. F. (1962). *Partitioning procedures for solving mixed-variables
   programming problems*. Numerische Mathematik, 4, 238–252.
   DOI: [10.1007/BF01386316](https://doi.org/10.1007/BF01386316).
   The project implements a basic master / LP-subproblem optimality-cut procedure
   for its own transport formulation. It does not claim to introduce Benders decomposition.

2. Shapley, L. S. (1953). *A Value for n-Person Games*. In H. W. Kuhn and A. W. Tucker
   (eds.), Contributions to the Theory of Games, Volume II, Princeton University Press,
   pp. 307–318. DOI: [10.1515/9781400881970-018](https://doi.org/10.1515/9781400881970-018).
   The weighted marginal-contribution formula is applied to a cooperative **cost** game.

Core feasibility and the minimum non-negative epsilon relaxation are defined
explicitly in [MODEL.md](MODEL.md). The latter should not be confused with an
unrestricted least-core or with a total subsidy calculation.

## Software used

- [SciPy `milp`](https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.milp.html):
  compact MILP and Benders master, solver status and MIP bounds.
- [SciPy `linprog` with HiGHS](https://docs.scipy.org/doc/scipy/reference/optimize.linprog-highs.html):
  continuous allocation subproblem, dual marginals and core-relaxation LP.
- [HiGHS](https://highs.dev/): the open-source optimisation engine reached through SciPy.
- [NumPy](https://numpy.org/doc/stable/): arrays, distances and reproducible random generation.
- [Matplotlib](https://matplotlib.org/stable/): static figures.
- [Python `unittest`](https://docs.python.org/3/library/unittest.html): validation without
  an additional test-runner dependency.

Direct dependency versions used for the reference run are pinned in
`requirements.txt`; the measured environment is in
`examples/reference_run/demo/environment.json`. Documentation URLs can describe
newer software releases than the pinned reference environment.

## Related learning resource, not a dependency

[PySCIPOpt's facility-location Benders example](https://github.com/scipopt/PySCIPOpt/blob/master/examples/finished/flp-benders.py)
is an alternative official example for studying decomposition with SCIP. This
repository uses SciPy / HiGHS instead and does not require or wrap that example.

## Provenance and claims

The problem formulation is a standard capacitated facility-location / allocation
structure adapted to a synthetic transport scenario. The source implementation
and explanatory documentation were prepared with AI assistance for this project.
The code was executed locally and its reference outputs were saved from actual
solves. Test and experiment evidence is included; there is no claimed external
peer review, publication, original theorem, deployment or real customer validation.

