# Mathematical model and interpretation

## 1. Sets, data and units

Let `N` be the set of companies and `S` a coalition. `I(S)` contains the orders
owned by members of `S`; `J` is the set of candidate consolidation hubs.

| Symbol | Meaning | Unit |
| --- | --- | --- |
| $d_i$ | Divisible demand of order $i$ | Load units per period |
| $f_j$ | Fixed charge to activate hub $j$ | EUR per period |
| $U_j$ | Capacity of hub $j$ | Load units per period |
| $c_{ij}$ | Cost per unit sent from common origin through hub $j$ to order $i$ | EUR / load unit |
| $p_i$ | Cost per unit sent directly from origin to order $i$ | EUR / load unit |

Synthetic Euclidean distances are used. With origin `o`, hub coordinate `h_j`
and customer coordinate `r_i`, the generator calculates

$$c_{ij}=r_L\lVert h_j-o\rVert+r_D\lVert r_i-h_j\rVert+k,$$

$$p_i=b+r_P\lVert r_i-o\rVert.$$

The rate parameters are synthetic tariff coefficients. Distances are illustrative
kilometres in an invented coordinate system; they are not actual Belgian routes.
`data/demo_instance.json` stores the baseline instance and all cost parameters.

## 2. Coalition planning MILP

Decisions are $y_j\in\{0,1\}$ (hub activation), $x_{ij}\geq0$ (flow through hub)
and $z_i\geq0$ (direct flow). For coalition $S$:

$$C(S)=\min\left\{\sum_{j\in J}f_jy_j+
\sum_{i\in I(S)}\sum_{j\in J}c_{ij}x_{ij}+
\sum_{i\in I(S)}p_i z_i\right\}$$

subject to demand conservation

$$\sum_{j\in J}x_{ij}+z_i=d_i\qquad\forall i\in I(S),$$

and activation / capacity constraints

$$\sum_{i\in I(S)}x_{ij}\leq U_jy_j\qquad\forall j\in J.$$

Define $C(\varnothing)=0$. Prices are finite and non-negative. Unlimited direct
delivery makes every coalition feasible, even with all hubs closed.

The compact solver uses the variable ordering `[y, x (row-major), z]`, sparse
constraint matrices and a requested MIP relative gap of zero. Only successful
optimal solves enter the cooperative cost table. Returned solutions are checked
for binary activations, non-negative flows, demand conservation, capacities
and objective reconstruction. Solver optimality is numerical, within solver tolerances.

### Coalition cost interpretation

Each coalition receives the same catalogue of hub-service offers, with one
activation and one capacity limit per hub. A singleton pays its own activation
charges; a coalition shares activation charges and capacity across its members.

The separate-operation baseline is the **sum of independently evaluated
standalone leasing plans**. These plans are counterfactual outside options.
They are not jointly constrained on one shared physical hub network. In contrast,
the pooled plan has one shared capacity $U_j$ at each hub, not one copy per member.

Consequently, enlarging a coalition can cause congestion and the model need not
be subadditive. Negative savings and an empty core are legitimate outcomes of
these assumptions. They do not prove that cooperation is harmful in a real network.
This convention makes the institutional assumptions visible rather than imposing
favourable cooperation results by construction.

For a different research question, member-owned capacity could be additive across
participants, or hub access could be jointly constrained across all competing
coalitions. Those would define different games and could change the conclusions.

## 3. Explicit Benders decomposition

Write the problem as

$$\min_{y\in\{0,1\}^{|J|}} f^Ty+Q(y).$$

For fixed $y$, `solve_recourse` solves the continuous shipment allocation LP.
Let $\alpha_i$ be the free dual of demand equality and $\beta_j\leq0$ the dual
of the hub-capacity inequality. Its dual is

$$Q(y)=\max_{\alpha,\beta}
\sum_i d_i\alpha_i+\sum_j U_jy_j\beta_j$$

subject to

$$\alpha_i+\beta_j\leq c_{ij},\qquad \alpha_i\leq p_i,\qquad \beta_j\leq0.$$

Demand equalities give free multipliers. Capacity constraints use a `<=` sign in
a minimisation LP, so their multipliers are non-positive. `linprog` exposes these
as `eqlin.marginals` and `ineqlin.marginals`; changing the primal row signs would
require changing the derivation.

Any dual feasible point $(\alpha^k,\beta^k)$ yields the global lower bound

$$\theta\geq\sum_i d_i\alpha_i^k+\sum_j U_j\beta_j^k y_j.$$

The master minimises $f^Ty+\theta$, with $y$ binary, $\theta\geq0$ and all
accumulated cuts. The zero lower bound on $\theta$ is valid because costs are
non-negative. In SciPy's upper-bound row format, a cut is stored as

$$\sum_j U_j\beta_j^k y_j-\theta\leq-\sum_i d_i\alpha_i^k.$$

Each iteration:

1. Solve the master to the requested zero MIP gap; update the global lower bound.
2. Solve the allocation LP for the chosen binary hubs.
3. Update the best feasible objective and keep its complete plan as the upper bound.
4. Stop when $(UB-LB)/\max(1,|UB|)\leq10^{-7}$.
5. Otherwise, verify strong duality at the current point and add its optimality cut.

The code stores the incumbent plan, not merely the last master solution. It
checks that the lower bound does not exceed the upper bound beyond tolerance.
A time or iteration limit raises an error instead of returning an unverified
optimality claim. The LP is bounded and feasible for every allowed hub vector
because of direct delivery, so this model needs **optimality cuts only**. Removing
that fallback could require feasibility cuts.

This is classical single-cut Benders in a Python outer loop. The repeated solver
initialisation and Python overhead can make it slower than the compact MILP.
Neither method is asserted to dominate on this small benchmark family.

## 4. Exact Shapley cost allocation

For each player $i$, the allocated cost is

$$\phi_i(C)=\sum_{S\subseteq N\setminus\{i\}}
\frac{|S|!(|N|-|S|-1)!}{|N|!}
\left[C(S\cup\{i\})-C(S)\right].$$

The implementation enumerates all coalitions and computes this formula exactly,
apart from solver and floating-point tolerances. It does not sample permutations.
Allocated costs sum to $C(N)$. A company saving is $C(\{i\})-\phi_i(C)$.
Cost shares may be negative: transferable utility allows monetary rebates.

Shapley allocation follows marginal-contribution fairness axioms. It is not
automatically individually rational or coalition-stable.

## 5. Core and blocking coalitions

An allocation $a$ is in the cost-game core if

$$\sum_{i\in N}a_i=C(N),\qquad
\sum_{i\in S}a_i\leq C(S)\quad\forall\varnothing\ne S\subsetneq N.$$

The first condition is efficiency. Singleton inequalities impose individual
rationality. Every larger proper-coalition inequality is also needed: otherwise
some participants could leave together and pay less.

Coalition excess is

$$e(S,a)=\sum_{i\in S}a_i-C(S).$$

A positive excess above `1e-5` EUR is reported as a blocking coalition. This is a
cost-game sign convention; some value-game definitions use the opposite sign.

To test whether **any** core allocation exists, solve

$$\min\epsilon$$

subject to

$$\sum_{i\in N}a_i=C(N),$$

$$\sum_{i\in S}a_i\leq C(S)+\epsilon
\quad\forall\varnothing\ne S\subsetneq N,\qquad \epsilon\geq0.$$

An optimum of zero indicates a non-empty core within tolerance. A positive
optimum is the smallest uniform non-negative relaxation needed for the proper
coalition inequalities. This is **not** the unrestricted least-core definition,
which permits negative epsilon. Nor is epsilon a total subsidy budget.
The returned allocation is one LP solution; the code does not optimise secondary
fairness within the core.

## 6. Experiments and computational scope

The main study evaluates 7 non-empty coalitions for 3 companies, compares the two
optimisation methods for the grand coalition and writes every plan, cost and check.

Sensitivity varies one factor at a time:

- Hub capacity: `0.5`, `1.0`, `1.5`.
- Fixed activation charges: `0.5`, `1.0`, `1.5`.
- Demand: `0.75`, `1.0`, `1.25` (capacity held fixed).

Coalition costs and allocations are recomputed for every distinct scenario;
identical baseline results are reused. `scenario_details.json` includes full
coalition tables, Shapley allocations, excesses and core-relaxation results.

The default algorithm benchmark pairs total orders/hubs `(18,4)`, `(36,6)`,
`(72,8)` with seeds `7`, `42`, `101`. It uses the grand coalition only, warms up
both methods outside the timer and alternates measured method order. Each pair
is measured once. Synthetic hub capacities scale with total generated demand.
The experiment establishes agreement on these instances, not general scalability
or a statistically robust runtime ranking. Run larger families and repeated
measurements before making stronger performance claims.

