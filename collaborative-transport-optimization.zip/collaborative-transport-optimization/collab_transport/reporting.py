"""Machine-readable experiment outputs and static figures for GitHub."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import StrMethodFormatter
import numpy as np

from .data import Instance
from .model import Solution

COLORS = ["#126782", "#229f87", "#df8d43", "#9c6bb3", "#d2596d", "#758e4f"]


def write_json(path: Path, obj: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def setup_style() -> None:
    plt.rcParams.update({"figure.facecolor": "#f6f8fb", "axes.facecolor": "#ffffff",
                         "axes.spines.top": False, "axes.spines.right": False,
                         "axes.titleweight": "bold", "axes.labelcolor": "#25364a",
                         "text.color": "#25364a", "font.size": 10,
                         "savefig.dpi": 160, "axes.prop_cycle": plt.cycler(color=COLORS)})


def save_figure(fig, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, bbox_inches="tight", facecolor=fig.get_facecolor())
    plt.close(fig)


def plot_network(instance: Instance, solution: Solution, path: Path) -> None:
    setup_style()
    fig, ax = plt.subplots(figsize=(9, 6))
    flow, direct = np.array(solution.flows), np.array(solution.direct)
    for i, order in enumerate(instance.orders):
        for j, hub in enumerate(instance.hubs):
            if flow[i, j] > 1e-6:
                ax.plot([hub.x, order.x], [hub.y, order.y], color="#bdc9d6",
                        lw=0.6 + flow[i, j] / 8, alpha=0.65, zorder=1)
        if direct[i] > 1e-6:
            ax.plot([instance.origin[0], order.x], [instance.origin[1], order.y],
                    color="#d4ad83", linestyle="--", lw=1, alpha=0.6, zorder=1)
    for k, company in enumerate(instance.companies):
        selected = [o for o in instance.orders if o.company == company]
        ax.scatter([o.x for o in selected], [o.y for o in selected],
                   s=[o.demand * 12 for o in selected], c=COLORS[k % len(COLORS)],
                   label=company, edgecolors="white", linewidths=0.8, zorder=3)
    for j, hub in enumerate(instance.hubs):
        active = solution.y[j] > 0.5
        if active:
            ax.plot([instance.origin[0], hub.x], [instance.origin[1], hub.y],
                    color="#7a8b9c", lw=2, alpha=0.6, zorder=1)
        ax.scatter(hub.x, hub.y, marker="s", s=145,
                   facecolors="#25364a" if active else "white",
                   edgecolors="#25364a", zorder=4)
        ax.annotate(hub.id, (hub.x, hub.y), xytext=(7, 7), textcoords="offset points")
    ax.scatter(*instance.origin, marker="*", s=250, c="#df8d43", zorder=5, label="Origin")
    ax.set(title="Shared transport network | synthetic instance",
           xlabel="Synthetic x coordinate (km)", ylabel="Synthetic y coordinate (km)")
    ax.set_aspect("equal", adjustable="datalim")
    ax.legend(loc="upper left", fontsize=8, frameon=False)
    ax.grid(alpha=0.12)
    fig.text(0.12, 0.005, "Squares: hubs (filled = activated). Dashed lines: direct delivery. "
             "Bubble area: demand. This is not a geographic map.", fontsize=8)
    save_figure(fig, path)


def plot_allocation(rows: list[dict], path: Path) -> None:
    setup_style()
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))
    x = np.arange(len(rows))
    axes[0].bar(x - 0.18, [r["standalone_cost"] for r in rows], width=0.36,
                label="Separate operations", color=COLORS[0])
    axes[0].bar(x + 0.18, [r["shapley_cost"] for r in rows], width=0.36,
                label="Shapley cost share", color=COLORS[1])
    axes[0].set_xticks(x, [r["company"].replace(" ", "\n") for r in rows])
    axes[0].set(title="Company costs", ylabel="EUR per planning period")
    axes[0].yaxis.set_major_formatter(StrMethodFormatter("{x:,.0f}"))
    axes[0].legend(frameon=False, fontsize=8)
    savings = [r["saving"] for r in rows]
    axes[1].bar(x, savings, color=[COLORS[1] if s >= 0 else "#bd4b55" for s in savings])
    axes[1].axhline(0, color="#25364a", lw=0.8)
    axes[1].set_xticks(x, [r["company"].replace(" ", "\n") for r in rows])
    axes[1].set(title="Savings after allocation", ylabel="EUR per planning period")
    for ax in axes:
        ax.grid(axis="y", alpha=0.12)
        ax.set_axisbelow(True)
    fig.tight_layout()
    save_figure(fig, path)


def plot_convergence(history: list[dict], path: Path) -> None:
    setup_style()
    fig, ax = plt.subplots(figsize=(8.5, 4.5))
    it = [r["iteration"] for r in history]
    ax.step(it, [r["lower_bound"] for r in history], where="post", label="Lower bound")
    ax.step(it, [r["upper_bound"] for r in history], where="post", label="Upper bound")
    ax.set(title="Benders convergence", xlabel="Master + LP iteration",
           ylabel="Objective bound (EUR)")
    ax.legend(frameon=False)
    ax.grid(alpha=0.15)
    save_figure(fig, path)


def plot_sensitivity(rows: list[dict], path: Path) -> None:
    setup_style()
    fig, axes = plt.subplots(1, 3, figsize=(12, 4), sharey=True)
    for ax, parameter in zip(axes, ("capacity", "fixed_cost", "demand")):
        selected = [r for r in rows if r["parameter"] == parameter]
        ax.plot([r["factor"] for r in selected], [r["savings_pct"] for r in selected],
                marker="o", color=COLORS[0])
        ax.set(title=parameter.replace("_", " ").title(), xlabel="Multiplier")
        ax.grid(alpha=0.15)
    axes[0].set_ylabel("Savings versus separate operations (%)")
    fig.suptitle("One-factor-at-a-time sensitivity | all coalition costs re-solved",
                 fontsize=12, fontweight="bold")
    fig.tight_layout()
    save_figure(fig, path)


def plot_benchmark(rows: list[dict], path: Path) -> None:
    setup_style()
    fig, ax = plt.subplots(figsize=(9, 4.7))
    x = np.arange(len(rows))
    ax.bar(x - 0.18, [r["compact_seconds"] for r in rows], width=0.36,
           label="Compact MILP", color=COLORS[0])
    ax.bar(x + 0.18, [r["benders_seconds"] for r in rows], width=0.36,
           label="Benders outer loop", color=COLORS[1])
    ax.set_xticks(x, [f"{r['n_orders']} orders / {r['n_hubs']} hubs\nseed {r['seed']}"
                      for r in rows], rotation=40, ha="right", fontsize=8)
    ax.set(title="Measured solver runtime | synthetic benchmark",
           ylabel="Wall-clock seconds")
    ax.legend(frameon=False)
    ax.grid(axis="y", alpha=0.15)
    fig.tight_layout()
    save_figure(fig, path)

