"""Compact MILP and continuous allocation subproblem, solved with HiGHS."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from time import perf_counter

import numpy as np
from scipy.optimize import Bounds, LinearConstraint, linprog, milp
from scipy.sparse import coo_matrix, csr_matrix, hstack, vstack

from .data import Instance


class OptimizationError(RuntimeError):
    """Raised when an optimization solve is not certified optimal."""


@dataclass
class Solution:
    method: str
    objective: float
    fixed_cost: float
    variable_cost: float
    y: list[float]
    flows: list[list[float]]
    direct: list[float]
    runtime_seconds: float
    lower_bound: float
    relative_gap: float
    iterations: int = 1
    status: str = "optimal"
    history: list[dict] = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class Recourse:
    objective: float
    flows: np.ndarray
    direct: np.ndarray
    alpha: np.ndarray
    beta: np.ndarray


def allocation_matrices(instance: Instance) -> tuple[csr_matrix, csr_matrix]:
    """Variables: row-major x[i,j], followed by direct quantities z[i]."""
    n, m = len(instance.orders), len(instance.hubs)
    flow_idx = np.arange(n * m)
    eq_rows = np.r_[np.repeat(np.arange(n), m), np.arange(n)]
    eq_cols = np.r_[flow_idx, n * m + np.arange(n)]
    demand_eq = coo_matrix((np.ones(n * m + n), (eq_rows, eq_cols)),
                           shape=(n, n * m + n)).tocsr()
    cap_rows = np.tile(np.arange(m), n)
    capacity_ub = coo_matrix((np.ones(n * m), (cap_rows, flow_idx)),
                             shape=(m, n * m + n)).tocsr()
    return demand_eq, capacity_ub


def solve_recourse(instance: Instance, y: np.ndarray, time_limit: float = 60) -> Recourse:
    """LP recourse is always feasible: direct transport has unlimited capacity.

    For capacity rows of the form A_ub @ x <= capacity*y, HiGHS returns
    non-positive marginal values beta. Demand equality marginals alpha are free.
    These duals give Q(y) >= demand@alpha + (capacity*beta)@y.
    """
    m = len(instance.hubs)
    y = np.asarray(y, dtype=float)
    if y.shape != (m,) or not np.isfinite(y).all() or np.any(y < 0) or np.any(y > 1):
        raise ValueError("Recourse requires one hub value in [0,1] per hub.")
    if not np.isfinite(time_limit) or time_limit <= 0:
        raise ValueError("Time limit must be finite and positive.")
    via, direct = instance.costs()
    demand_eq, capacity_ub = allocation_matrices(instance)
    demand = np.array([o.demand for o in instance.orders])
    capacity = np.array([h.capacity for h in instance.hubs])
    result = linprog(np.r_[via.ravel(), direct], A_ub=capacity_ub,
                     b_ub=capacity * y, A_eq=demand_eq, b_eq=demand,
                     bounds=(0, None), method="highs",
                     options={"time_limit": float(time_limit)})
    if not result.success or result.status != 0:
        raise OptimizationError(f"Allocation LP failed: {result.message}")
    nm = len(instance.orders) * m
    return Recourse(float(result.fun), result.x[:nm].reshape(-1, m), result.x[nm:],
                     np.asarray(result.eqlin.marginals),
                     np.asarray(result.ineqlin.marginals))


def make_solution(instance: Instance, method: str, y: np.ndarray,
                  flows: np.ndarray, direct: np.ndarray, runtime: float,
                  lower_bound: float, iterations: int = 1,
                  history: list[dict] | None = None) -> Solution:
    via, direct_costs = instance.costs()
    fixed = float(np.array([h.fixed_cost for h in instance.hubs]) @ y)
    variable = float(np.sum(via * flows) + direct_costs @ direct)
    total = fixed + variable
    if lower_bound > total + 1e-5:
        raise OptimizationError("Solver lower bound exceeds feasible objective.")
    solution = Solution(method, total, fixed, variable, y.tolist(), flows.tolist(),
                        direct.tolist(), runtime, float(lower_bound),
                        max(0.0, total - lower_bound) / max(1.0, abs(total)),
                        iterations, history=history or [])
    validate_solution(instance, solution)
    return solution


def validate_solution(instance: Instance, solution: Solution, tol: float = 1e-5) -> None:
    n, m = len(instance.orders), len(instance.hubs)
    y, x, z = map(np.asarray, (solution.y, solution.flows, solution.direct))
    if y.shape != (m,) or x.shape != (n, m) or z.shape != (n,):
        raise ValueError("Solution dimensions do not match the instance.")
    if not all(np.isfinite(a).all() for a in (y, x, z)):
        raise ValueError("Solution contains non-finite values.")
    if (np.any(y < -tol) or np.any(y > 1 + tol)
            or np.max(np.abs(y - np.round(y))) > tol):
        raise ValueError("Hub decisions are not binary.")
    if np.any(x < -tol) or np.any(z < -tol):
        raise ValueError("Negative shipment quantity.")
    demand = np.array([o.demand for o in instance.orders])
    capacity = np.array([h.capacity for h in instance.hubs])
    if not np.allclose(x.sum(axis=1) + z, demand, atol=tol, rtol=0):
        raise ValueError("Demand conservation violated.")
    if np.any(x.sum(axis=0) - capacity * y > tol):
        raise ValueError("Hub activation or capacity violated.")
    via, direct_costs = instance.costs()
    fixed = float(np.array([h.fixed_cost for h in instance.hubs]) @ y)
    variable = float(np.sum(via * x) + direct_costs @ z)
    if (not np.isclose(fixed, solution.fixed_cost, atol=tol, rtol=0)
            or not np.isclose(variable, solution.variable_cost, atol=tol, rtol=0)
            or not np.isclose(fixed + variable, solution.objective, atol=tol, rtol=0)):
        raise ValueError("Reported objective or cost components are inconsistent.")


def solve_compact(instance: Instance, time_limit: float = 60) -> Solution:
    if not np.isfinite(time_limit) or time_limit <= 0:
        raise ValueError("Time limit must be finite and positive.")
    start = perf_counter()
    n, m = len(instance.orders), len(instance.hubs)
    via, direct_costs = instance.costs()
    demand_eq, capacity_ub = allocation_matrices(instance)
    capacity = np.array([h.capacity for h in instance.hubs])
    # Full variable vector: y (binary), x (continuous), z (continuous).
    eq = hstack([csr_matrix((n, m)), demand_eq], format="csr")
    cap = hstack([-csr_matrix(np.diag(capacity)), capacity_ub], format="csr")
    matrix = vstack([eq, cap], format="csr")
    demand = np.array([o.demand for o in instance.orders])
    constraints = LinearConstraint(matrix, np.r_[demand, np.full(m, -np.inf)],
                                   np.r_[demand, np.zeros(m)])
    c = np.r_[[h.fixed_cost for h in instance.hubs], via.ravel(), direct_costs]
    total_vars = len(c)
    result = milp(c, integrality=np.r_[np.ones(m), np.zeros(total_vars - m)],
                  bounds=Bounds(np.zeros(total_vars),
                                np.r_[np.ones(m), np.full(total_vars - m, np.inf)]),
                  constraints=constraints,
                  options={"time_limit": float(time_limit), "mip_rel_gap": 0.0})
    if not result.success or result.status != 0:
        raise OptimizationError(f"Compact MILP not certified optimal: {result.message}")
    y = np.round(result.x[:m])
    x = result.x[m:m + n * m].reshape(n, m)
    z = result.x[m + n * m:]
    return make_solution(instance, "compact_milp", y, x, z,
                         perf_counter() - start, float(result.mip_dual_bound))

