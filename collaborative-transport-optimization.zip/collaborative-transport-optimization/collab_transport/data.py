"""Validated, serializable synthetic transport instances. Distances are synthetic km."""

from __future__ import annotations

from dataclasses import asdict, dataclass, replace
import json
import math
from pathlib import Path

import numpy as np


@dataclass(frozen=True)
class Hub:
    id: str
    x: float
    y: float
    fixed_cost: float
    capacity: float


@dataclass(frozen=True)
class Order:
    id: str
    company: str
    x: float
    y: float
    demand: float


@dataclass(frozen=True)
class Instance:
    name: str
    companies: tuple[str, ...]
    hubs: tuple[Hub, ...]
    orders: tuple[Order, ...]
    seed: int = 42
    origin: tuple[float, float] = (0.0, 0.0)
    linehaul_rate: float = 0.50
    delivery_rate: float = 1.05
    handling_cost: float = 2.0
    direct_rate: float = 1.80
    direct_base_cost: float = 4.0

    def __post_init__(self) -> None:
        if not self.name or not isinstance(self.name, str):
            raise ValueError("Instance name must be a non-empty string.")
        if not self.companies or len(set(self.companies)) != len(self.companies):
            raise ValueError("Companies must be non-empty and unique.")
        if any(not isinstance(c, str) or not c or "|" in c for c in self.companies):
            raise ValueError("Company names must be non-empty strings without '|'.")
        if not self.hubs or len({h.id for h in self.hubs}) != len(self.hubs):
            raise ValueError("Hubs must be non-empty with unique IDs.")
        if not self.orders or len({o.id for o in self.orders}) != len(self.orders):
            raise ValueError("Orders must be non-empty with unique IDs.")
        if len(self.origin) != 2:
            raise ValueError("Origin needs two coordinates.")
        rates = (self.linehaul_rate, self.delivery_rate, self.handling_cost,
                 self.direct_rate, self.direct_base_cost)
        if any(not math.isfinite(v) or v < 0 for v in rates):
            raise ValueError("Cost parameters must be finite and non-negative.")
        for h in self.hubs:
            if not h.id or not all(math.isfinite(v) for v in
                                   (h.x, h.y, h.fixed_cost, h.capacity)):
                raise ValueError("Hub fields must be valid and finite.")
            if h.fixed_cost < 0 or h.capacity <= 0:
                raise ValueError("Hub fixed cost must be non-negative and capacity positive.")
        for o in self.orders:
            if not o.id or o.company not in self.companies:
                raise ValueError("Order IDs and company membership must be valid.")
            if not all(math.isfinite(v) for v in (o.x, o.y, o.demand)) or o.demand <= 0:
                raise ValueError("Order demand must be positive and fields finite.")
        if {o.company for o in self.orders} != set(self.companies):
            raise ValueError("Every company needs at least one order.")
        if not all(math.isfinite(v) for v in self.origin):
            raise ValueError("Origin coordinates must be finite.")

    def subset(self, coalition: tuple[str, ...]) -> Instance:
        if not coalition or len(set(coalition)) != len(coalition):
            raise ValueError("Coalition must be non-empty without duplicates.")
        if not set(coalition).issubset(self.companies):
            raise ValueError("Coalition contains an unknown company.")
        members = tuple(c for c in self.companies if c in coalition)
        return replace(self, companies=members,
                       orders=tuple(o for o in self.orders if o.company in members))

    def costs(self) -> tuple[np.ndarray, np.ndarray]:
        customers = np.array([(o.x, o.y) for o in self.orders], dtype=float)
        hubs = np.array([(h.x, h.y) for h in self.hubs], dtype=float)
        origin = np.array(self.origin, dtype=float)
        linehaul = np.linalg.norm(hubs - origin, axis=1)
        last_leg = np.linalg.norm(customers[:, None, :] - hubs[None, :, :], axis=2)
        via = self.linehaul_rate * linehaul[None, :] + self.delivery_rate * last_leg
        via += self.handling_cost
        direct = self.direct_base_cost + self.direct_rate * np.linalg.norm(
            customers - origin, axis=1)
        return via, direct

    def write(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(asdict(self), indent=2, allow_nan=False) + "\n")


def load_instance(path: Path) -> Instance:
    raw = json.loads(path.read_text())
    raw["companies"] = tuple(raw["companies"])
    raw["hubs"] = tuple(Hub(**item) for item in raw["hubs"])
    raw["orders"] = tuple(Order(**item) for item in raw["orders"])
    if "origin" in raw:
        raw["origin"] = tuple(raw["origin"])
    return Instance(**raw)


def generate_instance(seed: int = 42, n_companies: int = 3,
                      orders_per_company: int = 6, n_hubs: int = 4) -> Instance:
    if not 1 <= n_companies <= 8:
        raise ValueError("Use 1 to 8 companies; exact coalition enumeration is exponential.")
    if orders_per_company < 1 or n_hubs < 1:
        raise ValueError("Orders per company and hubs must be positive.")
    rng = np.random.default_rng(seed)
    names = ("Scheldt Freight", "Delta Logistics", "Harbour Cargo")
    companies = tuple(names[i] if i < 3 else f"Carrier {i + 1}"
                      for i in range(n_companies))
    # All names, coordinates, tariffs and demands are fictional.
    base = ((12., 8.), (30., 12.), (15., 31.), (39., 33.))
    coords = [base[j] if j < len(base) else tuple(rng.uniform(8, 45, size=2))
              for j in range(n_hubs)]
    total_demand = 0.0
    orders = []
    for i, company in enumerate(companies):
        for k in range(orders_per_company):
            center = np.array(coords[(k + i) % n_hubs])
            x, y = np.maximum(1.0, center + rng.normal(0, 5, size=2))
            demand = float(rng.integers(4, 13))
            total_demand += demand
            orders.append(Order(f"O{i + 1:02d}-{k + 1:03d}", company,
                                round(float(x), 3), round(float(y), 3), demand))
    hubs = tuple(Hub(f"H{j + 1:02d}", float(x), float(y),
                     float(170 + 45 * j),
                     round(total_demand / n_hubs * 1.05, 3))
                 for j, (x, y) in enumerate(coords))
    return Instance(f"synthetic-antwerp-inspired-{seed}", companies, hubs,
                    tuple(orders), seed=seed)

