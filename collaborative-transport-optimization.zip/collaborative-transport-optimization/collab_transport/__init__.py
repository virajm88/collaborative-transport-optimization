"""A reproducible computational study of cooperative transport planning."""

__version__ = "0.1.0"

