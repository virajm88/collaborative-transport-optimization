"""Explicit single-cut Benders decomposition, using LP dual multipliers.

This is an outer loop, not a call to a solver's automatic decomposition feature.
The master chooses binary hubs and theta; the LP allocates divisible demand.
Unlimited direct delivery supplies relatively complete recourse, so only
optimality cuts are needed for this particular model.
"""

from __future__ import annotations

from time import perf_counter

import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp

from .data import Instance
from .model import OptimizationError, Solution, make_solution, solve_recourse


def solve_benders(instance: Instance, time_limit: float = 60,
                   tolerance: float = 1e-7, max_iterations: int = 500) -> Solution:
    """time_limit is a total wall-clock budget for this outer-loop solve.

    Stop when UB-LB <= tolerance*max(1,abs(UB)), with every master solved
    to its requested zero MIP gap. Refuse to label incomplete runs optimal.
    """
    if (not np.isfinite(time_limit) or time_limit <= 0
            or not np.isfinite(tolerance) or tolerance <= 0 or max_iterations < 1):
        raise ValueError("Time, tolerance and maximum iterations must be positive and finite.")
    start = perf_counter()
    m = len(instance.hubs)
    fixed = np.array([h.fixed_cost for h in instance.hubs])
    capacity = np.array([h.capacity for h in instance.hubs])
    demand = np.array([o.demand for o in instance.orders])
    c = np.r_[fixed, 1.0]
    cuts: list[np.ndarray] = []
    rhs: list[float] = []
    history: list[dict] = []
    lower_bound, upper_bound = -np.inf, np.inf
    best = None

    def remaining() -> float:
        value = time_limit - (perf_counter() - start)
        if value <= 0:
            raise OptimizationError("Benders wall-clock limit reached before convergence.")
        return value

    for iteration in range(1, max_iterations + 1):
        constraints = None if not cuts else LinearConstraint(
            np.vstack(cuts), np.full(len(cuts), -np.inf), np.array(rhs))
        master = milp(c, integrality=np.r_[np.ones(m), 0.0],
                      bounds=Bounds(np.zeros(m + 1), np.r_[np.ones(m), np.inf]),
                      constraints=constraints,
                      options={"time_limit": remaining(), "mip_rel_gap": 0.0})
        if not master.success or master.status != 0:
            raise OptimizationError(f"Benders master not optimal: {master.message}")
        lower_bound = max(lower_bound, float(master.mip_dual_bound))
        y = np.round(master.x[:m])
        sub = solve_recourse(instance, y, time_limit=remaining())
        candidate = float(fixed @ y + sub.objective)
        if candidate < upper_bound:
            upper_bound = candidate
            best = (y.copy(), sub)
        gap = max(0.0, upper_bound - lower_bound) / max(1.0, abs(upper_bound))
        history.append({"iteration": iteration, "lower_bound": float(lower_bound),
                        "upper_bound": float(upper_bound), "relative_gap": float(gap),
                        "candidate_objective": candidate,
                        "open_hubs": "|".join(h.id for h, value in zip(instance.hubs, y)
                                              if value > 0.5) or "none",
                        "runtime_seconds": perf_counter() - start})
        if lower_bound > upper_bound + 1e-5:
            raise OptimizationError("Invalid Benders bounds; check dual signs and cuts.")
        if gap <= tolerance:
            best_y, best_sub = best
            return make_solution(instance, "benders", best_y, best_sub.flows,
                                 best_sub.direct, perf_counter() - start,
                                 lower_bound, iteration, history)

        # theta >= d^T alpha + (U*beta)^T y.
        # scipy LinearConstraint uses <= RHS here: (U*beta)^T y - theta <= -d^T alpha.
        intercept = float(demand @ sub.alpha)
        slope = capacity * sub.beta
        if not np.isclose(intercept + slope @ y, sub.objective, atol=1e-5, rtol=1e-8):
            raise OptimizationError("LP strong-duality check failed; cannot add a valid cut.")
        cuts.append(np.r_[slope, -1.0])
        rhs.append(-intercept)

    raise OptimizationError(f"Benders did not converge within {max_iterations} iterations.")

