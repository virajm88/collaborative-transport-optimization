"""End-to-end reproducible experiments. Only certified solves enter cost games."""

from __future__ import annotations

from dataclasses import replace
import importlib.metadata
from pathlib import Path
import platform
import sys

import numpy as np

from . import __version__
from .benders import solve_benders
from .data import Instance, generate_instance
from .game import (assess_allocation, coalition_name, minimum_core_relaxation,
                    shapley_costs, solve_coalition_costs)
from .model import OptimizationError, solve_compact
from .reporting import (plot_allocation, plot_benchmark, plot_convergence,
                        plot_network, plot_sensitivity, write_csv, write_json)


def environment() -> dict:
    return {"project_version": __version__, "python": sys.version,
            "platform": platform.platform(), "machine": platform.machine(),
            "dependencies": {name: importlib.metadata.version(name)
                             for name in ("numpy", "scipy", "matplotlib")},
            "solver": "HiGHS via scipy.optimize.milp / linprog",
            "note": "Hardware, background load, warm-up and solver versions affect runtime."}


def check_objective_agreement(left: float, right: float) -> None:
    if not np.isclose(left, right, atol=1e-4, rtol=1e-7):
        raise OptimizationError(f"Methods disagree on objective: {left} versus {right}.")


def run_study(instance: Instance, output: Path, time_limit: float = 60) -> dict:
    output.mkdir(parents=True, exist_ok=True)
    instance.write(output / "instance.json")
    write_json(output / "environment.json", environment())
    costs, solutions = solve_coalition_costs(instance, time_limit=time_limit)
    grand = frozenset(instance.companies)
    compact = solutions[grand]
    benders = solve_benders(instance, time_limit=time_limit)
    check_objective_agreement(compact.objective, benders.objective)
    shapley = shapley_costs(instance.companies, costs)
    stability = assess_allocation(instance.companies, costs, shapley)
    core = minimum_core_relaxation(instance.companies, costs)
    separate = sum(costs[frozenset([p])] for p in instance.companies)
    saving = separate - compact.objective
    summary = {"instance": instance.name, "seed": instance.seed,
               "n_companies": len(instance.companies), "n_orders": len(instance.orders),
               "n_hubs": len(instance.hubs), "separate_cost": separate,
               "collaborative_cost": compact.objective, "saving": saving,
               "savings_pct": 100 * saving / separate if separate else 0.0,
               "shapley_allocation": shapley, "shapley_stability": stability,
               "core_relaxation": core, "compact_seconds": compact.runtime_seconds,
               "benders_seconds": benders.runtime_seconds,
               "benders_iterations": benders.iterations,
               "absolute_objective_difference": abs(compact.objective - benders.objective),
               "compact_relative_gap": compact.relative_gap,
               "benders_relative_gap": benders.relative_gap,
               "synthetic_data": True}
    write_json(output / "summary.json", summary)
    write_json(output / "compact_solution.json", compact.to_dict())
    write_json(output / "benders_solution.json", benders.to_dict())
    write_csv(output / "benders_history.csv", benders.history)
    coalition_rows = []
    for s, solution in solutions.items():
        coalition_rows.append({"coalition": coalition_name(s, instance.companies),
                               "size": len(s), "cost": costs[s],
                               "status": solution.status, "relative_gap": solution.relative_gap,
                               "lower_bound": solution.lower_bound,
                               "runtime_seconds": solution.runtime_seconds})
    write_csv(output / "coalition_costs.csv", coalition_rows)
    allocation_rows = [{"company": p, "standalone_cost": costs[frozenset([p])],
                        "shapley_cost": shapley[p],
                        "saving": costs[frozenset([p])] - shapley[p]}
                       for p in instance.companies]
    write_csv(output / "allocations.csv", allocation_rows)
    write_csv(output / "stability_checks.csv", stability["coalition_checks"])
    write_csv(output / "hub_utilization.csv", [
        {"hub": hub.id, "active": int(compact.y[j] > 0.5),
         "capacity": hub.capacity,
         "throughput": float(np.array(compact.flows)[:, j].sum())}
        for j, hub in enumerate(instance.hubs)])
    flow_rows = []
    for i, order in enumerate(instance.orders):
        for j, hub in enumerate(instance.hubs):
            quantity = compact.flows[i][j]
            if quantity > 1e-7:
                flow_rows.append({"order": order.id, "company": order.company,
                                  "route": hub.id, "quantity": quantity})
        if compact.direct[i] > 1e-7:
            flow_rows.append({"order": order.id, "company": order.company,
                              "route": "direct", "quantity": compact.direct[i]})
    write_csv(output / "flows.csv", flow_rows)
    plot_network(instance, compact, output / "figures/network.png")
    plot_allocation(allocation_rows, output / "figures/allocation.png")
    plot_convergence(benders.history, output / "figures/benders_convergence.png")
    write_study_report(instance, summary, allocation_rows, output / "report.md")
    return summary


def write_study_report(instance: Instance, summary: dict, allocations: list[dict],
                        path: Path) -> None:
    rows = "\n".join(f"| {r['company']} | {r['standalone_cost']:,.2f} | "
                     f"{r['shapley_cost']:,.2f} | {r['saving']:,.2f} |" for r in allocations)
    s = summary
    text = f"""# Collaborative transport planning: computed results

All data are synthetic. These are computational results, not observed commercial savings.

## Experiment

- Instance: `{instance.name}`; seed: {instance.seed}.
- {len(instance.companies)} companies, {len(instance.orders)} orders, {len(instance.hubs)} hubs.
- All costs are EUR per synthetic planning period; flows are divisible load units.
- Separate-operation cost: **EUR {s['separate_cost']:,.2f}**.
- Grand-coalition cost: **EUR {s['collaborative_cost']:,.2f}**.
- Modelled savings: **EUR {s['saving']:,.2f} ({s['savings_pct']:.2f}%)**.

## Exact Shapley cost allocation

| Company | Separate cost | Shapley cost | Saving |
| --- | ---: | ---: | ---: |
{rows}

- Efficient: **{s['shapley_stability']['efficient']}**.
- Individually rational: **{s['shapley_stability']['individually_rational']}**.
- Shapley allocation in the core: **{s['shapley_stability']['in_core']}**.
- Core exists: **{s['core_relaxation']['core_exists']}**.
- Minimum non-negative uniform coalition relaxation: **EUR {s['core_relaxation']['minimum_epsilon']:.6f}**.

Every proper coalition is checked in `stability_checks.csv`. A positive excess means
the coalition pays more than it would pay in isolation. Shapley fairness does not
guarantee stability. A core allocation, where one exists, need not be unique.

## Algorithm verification

| Method | Runtime (s) | Relative gap | Iterations |
| --- | ---: | ---: | ---: |
| Compact MILP | {s['compact_seconds']:.6f} | {s['compact_relative_gap']:.3g} | Solver managed |
| Explicit Benders | {s['benders_seconds']:.6f} | {s['benders_relative_gap']:.3g} | {s['benders_iterations']} |

Absolute objective difference: **{s['absolute_objective_difference']:.8f} EUR**.
Objective agreement is checked automatically; tied optimal flow plans may differ.
Hardware and dependency versions are in `environment.json`. One runtime is not
evidence of general superiority; use the multi-seed benchmark for broader comparisons.

![Network](figures/network.png)

![Allocation](figures/allocation.png)

![Benders bounds](figures/benders_convergence.png)

## Interpretation and limitations

This is a transferable-utility cooperative cost game built on a capacitated
hub-activation model. It assumes divisible demand, deterministic costs, a common
origin, enforceable transfers and unlimited direct delivery. Coalition costs are
counterfactual solves with identical hub-service offers; separate plans are not a
joint feasibility certificate for one physical network. Pooling does not receive
duplicated capacity from separately evaluated coalitions. Negative savings and
an empty core are possible; the code does not assume subadditivity.

This model is not a non-cooperative equilibrium, vehicle-routing problem, bilevel
model or implementation of column generation/branch-and-price. These experiments
do not establish a new theorem, a novel algorithm or real-world savings.
"""
    path.write_text(text, encoding="utf-8")


def sensitivity(instance: Instance, output: Path, time_limit: float = 60) -> list[dict]:
    output.mkdir(parents=True, exist_ok=True)
    rows = []
    details = []
    baseline = None
    for parameter, factors in (("capacity", (0.5, 1.0, 1.5)),
                               ("fixed_cost", (0.5, 1.0, 1.5)),
                               ("demand", (0.75, 1.0, 1.25))):
        for factor in factors:
            if factor == 1.0 and baseline is not None:
                costs, shapley, stability = baseline
            else:
                if parameter == "demand":
                    changed = replace(instance, orders=tuple(
                        replace(o, demand=o.demand * factor) for o in instance.orders))
                else:
                    field = "capacity" if parameter == "capacity" else "fixed_cost"
                    changed = replace(instance, hubs=tuple(
                        replace(h, **{field: getattr(h, field) * factor}) for h in instance.hubs))
                costs, _ = solve_coalition_costs(changed, time_limit=time_limit)
                shapley = shapley_costs(instance.companies, costs)
                stability = assess_allocation(instance.companies, costs, shapley)
                if factor == 1.0:
                    baseline = costs, shapley, stability
            separate = sum(costs[frozenset([p])] for p in instance.companies)
            pooled = costs[frozenset(instance.companies)]
            core = minimum_core_relaxation(instance.companies, costs)
            rows.append({"parameter": parameter, "factor": factor,
                         "separate_cost": separate, "collaborative_cost": pooled,
                         "savings_pct": 100 * (separate - pooled) / separate if separate else 0.0,
                         "shapley_in_core": stability["in_core"],
                         "core_exists": core["core_exists"],
                         "minimum_epsilon": core["minimum_epsilon"]})
            details.append({"parameter": parameter, "factor": factor,
                            "coalition_costs": {coalition_name(s, instance.companies): value
                                                for s, value in costs.items()},
                            "shapley_allocation": shapley, "stability": stability,
                            "core_relaxation": core})
    write_csv(output / "sensitivity.csv", rows)
    write_json(output / "scenario_details.json", details)
    write_json(output / "environment.json", environment())
    instance.write(output / "baseline_instance.json")
    plot_sensitivity(rows, output / "sensitivity.png")
    return rows


def benchmark(output: Path, orders: list[int], hubs: list[int], seeds: list[int],
               time_limit: float = 60) -> list[dict]:
    if len(orders) != len(hubs) or not orders or not seeds:
        raise ValueError("Supply equally long non-empty orders/hubs lists and at least one seed.")
    output.mkdir(parents=True, exist_ok=True)
    rows = []
    for per_company, n_hubs in zip(orders, hubs):
        for seed in seeds:
            instance = generate_instance(seed, 3, per_company, n_hubs)
            # Warm-up is not timed. Alternate measured solve order to reduce order effects.
            warmup = generate_instance(0, 1, 1, 1)
            solve_compact(warmup, time_limit=time_limit)
            solve_benders(warmup, time_limit=time_limit)
            if len(rows) % 2 == 0:
                compact = solve_compact(instance, time_limit=time_limit)
                benders = solve_benders(instance, time_limit=time_limit)
                solve_order = "compact_then_benders"
            else:
                benders = solve_benders(instance, time_limit=time_limit)
                compact = solve_compact(instance, time_limit=time_limit)
                solve_order = "benders_then_compact"
            check_objective_agreement(compact.objective, benders.objective)
            stem = f"o{len(instance.orders)}_h{n_hubs}_s{seed}"
            instance.write(output / "instances" / f"{stem}.json")
            write_csv(output / "histories" / f"{stem}.csv", benders.history)
            rows.append({"n_orders": len(instance.orders), "n_hubs": n_hubs,
                         "seed": seed, "solve_order": solve_order,
                         "compact_objective": compact.objective,
                         "benders_objective": benders.objective,
                         "absolute_difference": abs(compact.objective - benders.objective),
                         "compact_seconds": compact.runtime_seconds,
                         "benders_seconds": benders.runtime_seconds,
                         "compact_gap": compact.relative_gap,
                         "benders_gap": benders.relative_gap,
                         "benders_iterations": benders.iterations})
            write_csv(output / "benchmark.csv", rows)
    write_json(output / "environment.json", environment())
    plot_benchmark(rows, output / "benchmark.png")
    table = "\n".join(
        f"| {r['n_orders']} | {r['n_hubs']} | {r['seed']} | {r['compact_seconds']:.5f} | "
        f"{r['benders_seconds']:.5f} | {r['benders_iterations']} | {r['absolute_difference']:.3g} |"
        for r in rows)
    (output / "report.md").write_text(
        "# Algorithm comparison\n\n"
        "Both methods solve the same synthetic model. Every row passed an objective-agreement check.\n\n"
        "| Orders (total) | Hubs | Seed | Compact (s) | Benders (s) | Benders iterations | Objective difference |\n"
        "| ---: | ---: | ---: | ---: | ---: | ---: | ---: |\n" + table +
        "\n\n![Runtime](benchmark.png)\n\n"
        "Warm-up solves are excluded; measured method order alternates. Each instance is timed once. "
        "These are small synthetic problems from one generator and one machine. "
        "Runtime differences include Python overhead and depend on solver versions, hardware and load. "
        "They do not establish large-scale superiority. Capacity scales with generated total demand. "
        "Inspect benchmark.csv, histories/ and environment.json for the underlying measurements.\n",
        encoding="utf-8")
    return rows

