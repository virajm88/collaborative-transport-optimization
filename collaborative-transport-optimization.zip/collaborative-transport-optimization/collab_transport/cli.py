"""Command-line entry points; run `python -m collab_transport --help`."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from .benders import solve_benders
from .data import generate_instance, load_instance
from .experiments import benchmark, run_study, sensitivity
from .model import OptimizationError, solve_compact
from .reporting import write_json


def add_instance_options(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--instance", type=Path, help="Existing JSON instance; overrides generator options")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--companies", type=int, default=3)
    parser.add_argument("--orders-per-company", type=int, default=6)
    parser.add_argument("--hubs", type=int, default=4)


def instance_from(args):
    return load_instance(args.instance) if args.instance else generate_instance(
        args.seed, args.companies, args.orders_per_company, args.hubs)


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="Collaborative transport optimisation research project")
    commands = parser.add_subparsers(dest="command", required=True)

    gen = commands.add_parser("generate", help="Write a reproducible synthetic instance")
    add_instance_options(gen)
    gen.add_argument("--output", type=Path, default=Path("outputs/instance.json"))

    demo = commands.add_parser("demo", help="MILP + Benders + all coalitions + report and figures")
    add_instance_options(demo)
    demo.add_argument("--output", type=Path, default=Path("outputs/demo"))
    demo.add_argument("--time-limit", type=float, default=60,
                      help="Seconds per MILP or complete Benders run (default: 60)")

    solve = commands.add_parser("solve", help="Solve one instance without game analysis")
    add_instance_options(solve)
    solve.add_argument("--method", choices=("compact", "benders"), default="compact")
    solve.add_argument("--output", type=Path, default=Path("outputs/solution.json"))
    solve.add_argument("--time-limit", type=float, default=60)

    sens = commands.add_parser("sensitivity", help="One-factor capacity, cost and demand experiments")
    add_instance_options(sens)
    sens.add_argument("--output", type=Path, default=Path("outputs/sensitivity"))
    sens.add_argument("--time-limit", type=float, default=60)

    bench = commands.add_parser("benchmark", help="Compact MILP versus Benders, paired sizes and seeds")
    bench.add_argument("--output", type=Path, default=Path("outputs/benchmark"))
    bench.add_argument("--orders", nargs="+", type=int, default=[6, 12, 24],
                       help="Orders PER COMPANY, paired with --hubs")
    bench.add_argument("--hubs", nargs="+", type=int, default=[4, 6, 8])
    bench.add_argument("--seeds", nargs="+", type=int, default=[7, 42, 101])
    bench.add_argument("--time-limit", type=float, default=60)

    args = parser.parse_args(argv)
    try:
        if args.command == "generate":
            instance_from(args).write(args.output)
            print(f"Wrote {args.output}")
        elif args.command == "demo":
            result = run_study(instance_from(args), args.output, args.time_limit)
            brief = {k: result[k] for k in ("separate_cost", "collaborative_cost",
                                          "savings_pct", "benders_iterations")}
            brief["shapley_in_core"] = result["shapley_stability"]["in_core"]
            print(json.dumps(brief, indent=2))
            print(f"Report: {args.output / 'report.md'}")
        elif args.command == "solve":
            function = solve_compact if args.method == "compact" else solve_benders
            result = function(instance_from(args), time_limit=args.time_limit)
            write_json(args.output, result.to_dict())
            print(f"{result.method}: EUR {result.objective:.6f}; gap {result.relative_gap:.3g}")
        elif args.command == "sensitivity":
            rows = sensitivity(instance_from(args), args.output, args.time_limit)
            print(f"Completed {len(rows)} scenarios: {args.output / 'sensitivity.csv'}")
        elif args.command == "benchmark":
            rows = benchmark(args.output, args.orders, args.hubs, args.seeds, args.time_limit)
            print(f"Verified objective agreement on {len(rows)} instances: "
                  f"{args.output / 'benchmark.csv'}")
    except (ValueError, OSError, OptimizationError) as error:
        parser.error(str(error))

