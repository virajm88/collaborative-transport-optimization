"""Exact cooperative cost games: Shapley allocation, core and epsilon relaxation."""

from __future__ import annotations

from itertools import combinations
from math import factorial, isfinite

import numpy as np
from scipy.optimize import linprog

from .data import Instance
from .model import OptimizationError, Solution, solve_compact

Coalition = frozenset[str]
CostTable = dict[Coalition, float]


def coalitions(players: tuple[str, ...], include_empty: bool = False):
    for size in range(0 if include_empty else 1, len(players) + 1):
        for members in combinations(players, size):
            yield frozenset(members)


def validate_game(players: tuple[str, ...], costs: CostTable) -> None:
    if not players or len(set(players)) != len(players):
        raise ValueError("Players must be non-empty and unique.")
    if len(players) > 8:
        raise ValueError("Exact analysis is limited to 8 players (255 non-empty coalitions).")
    expected = set(coalitions(players, include_empty=True))
    if set(costs) != expected or costs[frozenset()] != 0:
        raise ValueError("Cost table must contain every coalition, with C(empty)=0.")
    if not all(isfinite(value) for value in costs.values()):
        raise ValueError("Coalition costs must be finite.")


def coalition_name(coalition: Coalition, players: tuple[str, ...]) -> str:
    return "|".join(p for p in players if p in coalition) or "empty"


def solve_coalition_costs(instance: Instance, time_limit: float = 60
                          ) -> tuple[CostTable, dict[Coalition, Solution]]:
    if len(instance.companies) > 8:
        raise ValueError("Exact coalition enumeration is limited to 8 companies.")
    costs: CostTable = {frozenset(): 0.0}
    solutions = {}
    for coalition in coalitions(instance.companies):
        members = tuple(p for p in instance.companies if p in coalition)
        solution = solve_compact(instance.subset(members), time_limit=time_limit)
        costs[coalition] = solution.objective
        solutions[coalition] = solution
    return costs, solutions


def shapley_costs(players: tuple[str, ...], costs: CostTable) -> dict[str, float]:
    """Allocate costs by exact weighted marginal contributions (not sampled)."""
    validate_game(players, costs)
    n = len(players)
    allocation = {}
    for player in players:
        others = tuple(p for p in players if p != player)
        share = 0.0
        for size in range(n):
            weight = factorial(size) * factorial(n - size - 1) / factorial(n)
            for members in combinations(others, size):
                s = frozenset(members)
                share += weight * (costs[s | {player}] - costs[s])
        allocation[player] = float(share)
    return allocation


def assess_allocation(players: tuple[str, ...], costs: CostTable,
                       allocation: dict[str, float], tolerance: float = 1e-5) -> dict:
    validate_game(players, costs)
    if set(allocation) != set(players) or not all(isfinite(v) for v in allocation.values()):
        raise ValueError("Allocation must give each player exactly one finite cost share.")
    if not isfinite(tolerance) or tolerance <= 0:
        raise ValueError("Tolerance must be finite and positive.")
    grand = frozenset(players)
    efficiency_error = sum(allocation.values()) - costs[grand]
    rows = []
    for s in coalitions(players):
        assigned = sum(allocation[p] for p in s)
        excess = assigned - costs[s]
        rows.append({"coalition": coalition_name(s, players), "size": len(s),
                     "standalone_cost": float(costs[s]), "allocated_cost": float(assigned),
                     "excess": float(excess), "wants_to_leave": bool(excess > tolerance)})
    violations = [r for r in rows if r["size"] < len(players) and r["wants_to_leave"]]
    return {"efficient": bool(abs(efficiency_error) <= tolerance),
            "efficiency_error": float(efficiency_error),
            "individually_rational": bool(all(
                allocation[p] <= costs[frozenset([p])] + tolerance for p in players)),
            "in_core": bool(abs(efficiency_error) <= tolerance and not violations),
            "blocking_coalitions": violations, "coalition_checks": rows}


def minimum_core_relaxation(players: tuple[str, ...], costs: CostTable,
                            tolerance: float = 1e-5) -> dict:
    """Minimize epsilon >= 0 s.t. efficiency and sum(a_i,S) <= C(S)+epsilon.

    A zero optimum certifies non-empty core. A positive optimum is the smallest
    uniform non-negative relaxation of all proper-coalition inequalities.
    This is not the unrestricted least-core, whose epsilon can be negative.
    Transfers are permitted: individual shares may be negative.
    """
    validate_game(players, costs)
    if not isfinite(tolerance) or tolerance <= 0:
        raise ValueError("Tolerance must be finite and positive.")
    n = len(players)
    matrix, rhs = [], []
    for s in coalitions(players):
        if len(s) == n:
            continue
        matrix.append([float(p in s) for p in players] + [-1.0])
        rhs.append(costs[s])
    result = linprog(np.r_[np.zeros(n), 1.0],
                     A_ub=np.array(matrix) if matrix else None,
                     b_ub=np.array(rhs) if rhs else None,
                     A_eq=np.array([[1.0] * n + [0.0]]),
                     b_eq=[costs[frozenset(players)]],
                     bounds=[(None, None)] * n + [(0.0, None)], method="highs")
    if not result.success:
        raise OptimizationError(f"Core relaxation LP failed: {result.message}")
    allocation = {p: float(result.x[i]) for i, p in enumerate(players)}
    return {"core_exists": bool(result.x[-1] <= tolerance),
            "minimum_epsilon": float(result.x[-1]), "allocation": allocation,
            "assessment": assess_allocation(players, costs, allocation, tolerance)}

