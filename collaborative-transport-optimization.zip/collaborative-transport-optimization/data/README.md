# Synthetic input data

- `demo_instance.json`: seeded 3-company, 18-order, 4-hub instance used in the main study.
- `tiny_instance.json`: two companies, one hub and a hand-computable EUR 45 optimum.

Every coordinate, company name, tariff, demand and capacity is fictional. No personal,
commercial or actual Belgian logistics data are included. Coordinate units are
illustrative kilometres; demand is divisible load units per planning period.
See `docs/MODEL.md` for the tariff formula and `collab_transport/data.py` for validation.

To generate additional JSON:

```bash
python -m collab_transport generate --seed 17 --output outputs/new_instance.json
```

JSON fields are `name`, `companies`, `hubs`, `orders`, `seed`, `origin` and the five
cost coefficients. Each hub has `id`, `x`, `y`, `fixed_cost`, `capacity`.
Each order has `id`, `company`, `x`, `y`, `demand`. Company names must not contain
`|`, which is reserved as a delimiter in coalition output labels.

